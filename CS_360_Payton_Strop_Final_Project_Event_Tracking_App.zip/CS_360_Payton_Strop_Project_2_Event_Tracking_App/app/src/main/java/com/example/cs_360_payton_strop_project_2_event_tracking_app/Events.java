package com.example.cs_360_payton_strop_project_2_event_tracking_app;
import java.util.Calendar;
public class Events {
    private int id;
    private String title;
    private Calendar date;
    private String description;
    private String eventUsername;
    public Events() {
        // Default constructor
    }
    // Getter and Setter methods
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public Calendar getDate() {
        return date;
    }
    public void setDate(Calendar date) {
        this.date = date;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getEventUsername() {
        return eventUsername;
    }
    public void setEventUsername(String eventUsername) {
        this.eventUsername = eventUsername;
    }
}
