package com.example.cs_360_payton_strop_project_2_event_tracking_app;

import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private CalendarView calendarView;
    private LinearLayout eventDetailsLayout;
    private TextView eventDetailsTextView;
    private ImageView addEventIcon;
    private ImageView deleteEventIcon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.login_screen);
        // Set a listener for the calendar view to handle date selection
        calendarView.setOnDateChangeListener((CalendarView view, int year, int month, int dayOfMonth) -> {
            // Handle date selection here
            updateEventDetails(year, month, dayOfMonth);
        });
        // Set a click listener for the add event icon
        addEventIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle add event action
            }
        });
        // Set a click listener for the delete event icon
        deleteEventIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle delete event action
            }
        });
    }
    private void updateEventDetails(int year, int month, int dayOfMonth) {
        // Logic to fetch and display events for the selected date
        String eventDetails = getEventDetails(year, month, dayOfMonth);
        if (!eventDetails.isEmpty()) {
            eventDetailsLayout.setVisibility(View.VISIBLE);
            eventDetailsTextView.setText(eventDetails);
        }
        else {
            eventDetailsLayout.setVisibility(View.GONE);
        }
    }
    private String getEventDetails(int year, int month, int dayOfMonth) {
        // Implement logic to retrieve events for the given date then,
        // fetch events from database and return event details as a string
        return "Event Details for " + dayOfMonth + "/" + (month + 1) + "/" + year;
    }
    public void setCalendarView(CalendarView calendarView) {
        this.calendarView = calendarView;
    }
    public void setEventDetailsTextView(TextView eventDetailsTextView) {
        this.eventDetailsTextView = eventDetailsTextView;
    }
    public void setDeleteEventIcon(ImageView deleteEventIcon) {
        this.deleteEventIcon = deleteEventIcon;
    }
}
