package com.example.cs_360_payton_strop_project_2_event_tracking_app;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.annotation.NonNull;
import java.util.List;
public class GridAdapter extends RecyclerView.Adapter<GridAdapter.ViewHolder> {
    private List<GridItem> items;
    public GridAdapter(List<GridItem> items) {
        this.items = items;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for each item in the RecyclerView
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_event_screen, parent, false);
        return new ViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind the data to the views in each ViewHolder
        GridItem item = items.get(position);
        holder.textViewDate.setText(item.getDate());
        holder.textStartTime.setText(item.getTime());
        holder.textEndTime.setText(item.getTime());
        holder.editTextTitle.setText(item.getTitle());
        holder.editTextDescription.setText(item.getDescription());
    }
    @Override
    public int getItemCount() {
        // Return the number of items in the data set
        return items.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDate;
        TextView textStartTime;
        TextView textEndTime;
        EditText editTextTitle;
        EditText editTextDescription;
        Button buttonSave;
        Button buttonDelete;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views in the ViewHolder
            textViewDate = itemView.findViewById(R.id.newEventDate);
            textStartTime = itemView.findViewById(R.id.newEventStartTime);
            textEndTime = itemView.findViewById(R.id.newEventEndTime);
            editTextTitle = itemView.findViewById(R.id.newEventName);
            editTextDescription = itemView.findViewById(R.id.newEventInfo);
            buttonSave = itemView.findViewById(R.id.newEventButton);
            buttonDelete = itemView.findViewById(R.id.newEventCancelButton);
        }
    }
}
