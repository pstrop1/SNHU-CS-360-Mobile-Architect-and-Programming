package com.example.cs_360_payton_strop_project_2_event_tracking_app;
import java.util.List;
public class GridItem {
    private String date;
    private String time;
    private String title;
    private String description;
    private List<String> list;
    public GridItem(String date, String time, String title, String description, List<String> list) {
        this.date = date;
        this.time = time;
        this.title = title;
        this.description = description;
        this.list = list;
    }
    // Getter methods
    public String getDate() {
        return date;
    }
    public String getTime() {
        return time;
    }
    public String getTitle() {
        return title;
    }
    public String getDescription() {
        return description;
    }
    public List<String> getList() {
        return list;
    }
}
