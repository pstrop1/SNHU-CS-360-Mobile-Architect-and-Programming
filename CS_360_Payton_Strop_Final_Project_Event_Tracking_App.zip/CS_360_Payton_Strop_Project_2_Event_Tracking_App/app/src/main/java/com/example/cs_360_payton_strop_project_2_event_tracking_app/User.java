package com.example.cs_360_payton_strop_project_2_event_tracking_app;

public class User {
    private String username;
    private String password;
    private int smsBool;

    public User() {
        this.username = username;
        this.password = password;
        this.smsBool = smsBool;
    }
    // Getter and Setter methods
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username= username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public int getSmsBool() {
        return smsBool;
    }
    public void setSmsBool(int smsBool) {
        this.smsBool = smsBool;
    }
}
